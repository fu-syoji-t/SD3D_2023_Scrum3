<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/homea.css">
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
<a onclick="location.href='../AnotherSky/login.php'" value=""><h2 style="text-align: right;">log in&nbsp;&nbsp;</h2></a>
    <?php  require_once 'header.php' ?>
</div>
<div><hr /></div>
<div>
  <h2>
    <div style="text-align: center;"></div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;">九州地方</span>
      <br />
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;"><br /></span>
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;">title</span>
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;"><br /></span>
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;">title</span>
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;"><br /></span>
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;">title</span>
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;"><br /></span>
    </div>
  </h2>
  <h2>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;">title</span>
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;"><br /></span>
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;">title</span>
      <span style="font-size: 36px; font-family: serif;"><br /></span>
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;"><br /></span>
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;">title</span>
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;"><br /></span>
    </div>
  </h2>
  <h2><div style="text-align: center;"></div></h2>
  <h2>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;">title</span>
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;"><br /></span>
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;">title</span>
    </div>
    <div style="text-align: center;">
      <span style="font-size: 36px; font-family: serif;"><br /></span>
    </div>
  </h2>
  <h2>
    <div style="text-align: center;">
      <hr />
      <?php  require_once 'footer.php' ?>
    </div>
  </h2>
</div>

</body>
</html>