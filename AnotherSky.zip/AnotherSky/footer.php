<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<style>
        .h6{
          background-color: #DDDDDD;
          margin: 30px auto;
          overflow: hidden;
          padding: 15px;
          width: 100vw;
        }
    </style>
<footer>
  <div class="h6"style="text-align: center;">
      <hr />
      <font face="serif">@Another Sky</font>
    </div>
  </footer>
</body>
</html>