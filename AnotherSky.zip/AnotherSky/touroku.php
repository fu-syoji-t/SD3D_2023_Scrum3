<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<style>
        /* CSSスタイルで中央配置を指定 */
        .centered-form {
            text-align: center; /* テキストを中央に配置 */
            position: absolute; /* 絶対位置指定 */
            top: 20%; /* 上から20%の位置に配置 */
            left: 50%; /* 左から50%の位置に配置 */
            transform: translate(-50%, -50%); /* 中央に配置 */
        }

        /* ログインフォームのスタイル */
        .login-form {
            margin-top: 20px;
            text-align: center;
        }

        /* 入力フィールドのスタイル */
        .input-field {
            width: 300px;
            padding: 10px;
            margin: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        /* 送信ボタンのスタイル */
        .submit-button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
    <div class="centered-form">
        <?php
            echo "新規登録";
        ?>
        <div class="login-form">
            <form action="login.php" method="post">
                <input type="text" class="input-field" name="email" placeholder="メールアドレス" required><br> <!-- ユーザー名の入力フィールドをメールアドレスに変更 -->
                <input type="password" class="input-field" name="password" placeholder="パスワード" required><br>
                <input type="text" class="input-field" name="name" placeholder="名前" required><br>
                <input type="submit" class="submit-button" value="登録">
            </form>
        </div>
    </div>
</body>
</html>
